# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['machine_tools', 'machine_tools.data', 'machine_tools.obj']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.5.1,<2.0.0']

setup_kwargs = {
    'name': 'machine-tools',
    'version': '0.1.0',
    'description': '',
    'long_description': '# `machine_tools`\n\n`machine_tools` - модуль работы с базой данных станков.\n\nПоддерждиваемые функции:\n\n\tПолучение списка станков:\n\t\tnames = machine_tools.list_mt(group=any_group, type_=any_type)\n\n\tПолучение характеристик станка (в формате DataFrame):\n\t\tchars = machine_tools.characteristics(name=any_name)\n\n\tПолучение паспортных данных станка (в формате DataFrame):\n\t\ttable = machine_tools.passport_data(name=any_name)\n\n',
    'author': 'Andrey Nikolaevich Korenyuk',
    'author_email': 'korenyuk.a.n@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
