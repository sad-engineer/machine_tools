# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['machine_tools', 'machine_tools.data', 'machine_tools.obj']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'machine-tools',
    'version': '0.1.0',
    'description': '',
    'long_description': '# `machine_tools`\n\n`machine_tools` - модуль работы с базой данных станков\nПоддерждиваемые функции:\n\tПолучение строки параметров инструмента по обозначению\n\tПолучение таблицы инструментов\n\tЗагрузка инструментов из таблицы эксель.\n',
    'author': 'Andrey Nikolaevich Korenyuk',
    'author_email': 'korenyuk.a.n@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
